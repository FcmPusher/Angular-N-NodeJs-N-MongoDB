module.exports.authController = require('./auth.controller');
module.exports.userController = require('./user.controller');
module.exports.orgnationController = require('./orgnation.controller');
module.exports.productController = require('./product.controller');
module.exports.fcmtokenController = require('./fcmtoken.controller');
module.exports.fragmentController = require('./fragment.controller');
