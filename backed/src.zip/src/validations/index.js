module.exports.authValidation = require('./auth.validation');
module.exports.userValidation = require('./user.validation');
module.exports.organizationValidation = require('./organization.validation');
module.exports.productValidation = require('./product.validation');
module.exports.fcmtokenValidation = require('./fcmtoken.validation');
module.exports.fragmentValidation = require('./fragment.validation');
